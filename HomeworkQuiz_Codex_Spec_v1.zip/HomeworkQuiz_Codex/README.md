# AI Homework Quiz — Codex 開發文件包

此包是**規格與提示詞，不是已完成的程式**。

- `DEVELOPMENT_SPEC.md`：完整產品規格、工作流程、資料結構、開發期程及驗收。
- `PROMPTS_REVISED.md`：依使用者提供提示詞改寫之分類、觀念萃取、個別化出題、批改提示詞。
- `AGENTS.md`：Codex 專案層級實作指引，可放入 GitHub repository 根目錄。
- `PROMPTS_AND_STEPS_ORIGINAL.md`：原始使用者參考文件備份。

## 如何交給 Codex

1. 在 GitHub 新建空白 repo，將本包四個 Markdown 放入根目錄。
2. 在 Codex 中開啟該 repo，輸入：`請先閱讀 AGENTS.md、DEVELOPMENT_SPEC.md、PROMPTS_REVISED.md，依規格從 Phase 0 開始實作。每一階段完成後執行 build/test，明確回報尚未驗證的 API CORS 限制。不要製作需後端的功能。`
3. 先完成 GitHub Pages 部署與真實 API 連線測試，再接續批次上傳、出題、HTML、批改流程。

## 注意事項

- 不要把真實 OpenAI 或 CGU API Key 提交到公開 GitHub。
- 原始文件曾提醒既有 PHP 專案可能硬編碼 API Key；若該金鑰仍有效且可能已暴露，請先輪替。
- 使用 browser-only 的 BYOK 方案有 XSS/金鑰暴露與 CORS 限制。
